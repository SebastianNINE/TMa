var app = {
    initialize: function() {
        window.location="https://google.sk";
    }
};
